<?php

$number = 1;

do {
     echo $number . " ";
     $number++;
} while ($number <= 10);


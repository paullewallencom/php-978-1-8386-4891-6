<?php
$age = 12;

if ($age > 25) {
        print("Adult");
} elseif ($age >= 18) {
        print("Young");
} elseif ($age > 10) {
        print("Teenager");
} else {
        print("Child");
}


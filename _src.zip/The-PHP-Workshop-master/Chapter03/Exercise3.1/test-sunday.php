<?php
if ("Sunday" === date("l")) {
        echo "Get rest";
} else {
        echo "Get ready and go to the office";
}


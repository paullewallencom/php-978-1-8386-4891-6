<?php

$days = ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

foreach ($days as $day) {
	echo $day . " ";
}


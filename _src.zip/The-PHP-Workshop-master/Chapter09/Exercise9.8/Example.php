<?php

namespace Packt;

class Example
{
    public function doSomething()
    {
        echo "PHP is great!" . PHP_EOL;
    }
}

<?php

require 'vendor/autoload.php';

use Packt\Example;

$e = new Example();
$e->doSomething();

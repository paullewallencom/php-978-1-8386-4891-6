<?php
$name = $argv[1];
echo "Hello ". $argv[1];
?>
<?php
$name = $_GET['companyName'];
echo "Hello ". $name;
?>
<h1><?php echo "Hello ". $_GET['companyName'];?>!</h1>
<hr>
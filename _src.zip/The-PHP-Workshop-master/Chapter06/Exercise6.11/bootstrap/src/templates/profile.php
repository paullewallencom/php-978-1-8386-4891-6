<section class="my-5">
    <h4>Welcome, <?= $username ?>!</h4>
</section>

<p>Session data: </p>
<pre><code><?= $sessionData ?></code></pre>

<hr class="my-5">

<p><a href="/logout">Logout</a></p>

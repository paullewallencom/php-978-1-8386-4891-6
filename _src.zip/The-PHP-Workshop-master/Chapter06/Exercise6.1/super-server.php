<?php echo sprintf("<pre>%s</pre>", print_r($_SERVER, true));

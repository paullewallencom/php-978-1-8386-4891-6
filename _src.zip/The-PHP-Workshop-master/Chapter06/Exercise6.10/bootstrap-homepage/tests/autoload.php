<?php

require_once __DIR__ . '/../src/components/Template.php';
require_once __DIR__ . '/Tests/TemplateTest.php';

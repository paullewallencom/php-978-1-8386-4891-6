<?php
$shapes = [
'circle',
'rectangle',
'triangle'
];

echo $shapes;

print_r($shapes);
<?php

echo substr('Hello World', 0, 5);

echo PHP_EOL;

echo substr('Hello World', 5);

echo substr('Hello World', -4, 3);

echo substr('idee�n', -3);

echo mb_substr('idee�n', -3);
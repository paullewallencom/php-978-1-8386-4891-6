INSERT INTO app.contacts (id, user_id, name, phone, email, address) VALUES (1, 2, 'Alonzo E Barber', '818-740-3656', 'alonzo@barber.com', '848  Glendale Avenue
Los Angeles
California
90017');
INSERT INTO app.contacts (id, user_id, name, phone, email, address) VALUES (2, 2, 'Annmarie N Reeves', '413-626-0746', 'annmarie@reeves.com', '3984  Leverton Cove Road
Springfield
Massachusetts
01109');
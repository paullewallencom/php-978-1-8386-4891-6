<div class="jumbotron">
    <h1 class="display-4">Hello!</h1>
    <p class="lead"><a href="/signup">Sign up</a> to start creating your contacts list.</p>
    <p class="lead">Already have an account? <a href="/login">Login here</a>.</p>
</div>
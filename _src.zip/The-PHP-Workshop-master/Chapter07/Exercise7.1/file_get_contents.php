<?php echo file_get_contents(__DIR__ . '/sample/users_list.csv');
